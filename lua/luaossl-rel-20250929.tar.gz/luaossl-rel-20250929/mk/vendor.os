#!/bin/sh

uname -s
